---
name: cross-model-handoff-testing
description: Test cross-model context handoff integrity.
---

## Instructions

1. Initialize cross-model-handoff-testing operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute cross-model-handoff-testing protocol"
- "Run cross model handoff testing analysis"
