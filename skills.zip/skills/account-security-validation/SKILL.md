---
name: account-security-validation
description: Validate account security and authentication protocols.
---

## Instructions

1. Initialize account-security-validation operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute account-security-validation protocol"
- "Run account security validation analysis"
