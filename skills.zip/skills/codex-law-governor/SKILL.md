---
name: codex-law-governor
description: Govern agent behavior through enforcement of the Codex Laws framework.
---

## Instructions

1. Initialize codex-law-governor operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute codex-law-governor protocol"
- "Run codex law governor analysis"
