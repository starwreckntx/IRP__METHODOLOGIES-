---
name: intervention-tier-classifier
description: Classify intervention urgency and apply appropriate response tier protocols.
---

## Instructions

1. Initialize intervention-tier-classifier operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute intervention-tier-classifier protocol"
- "Run intervention tier classifier analysis"
