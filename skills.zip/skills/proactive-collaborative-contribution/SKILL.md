---
name: proactive-collaborative-contribution
description: Contribute proactively to collaborative workflows.
---

## Instructions

1. Initialize proactive-collaborative-contribution operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute proactive-collaborative-contribution protocol"
- "Run proactive collaborative contribution analysis"
