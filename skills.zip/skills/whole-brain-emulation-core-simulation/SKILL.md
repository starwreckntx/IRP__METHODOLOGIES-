---
name: whole-brain-emulation-core-simulation
description: Simulate whole-brain emulation core processes.
---

## Instructions

1. Initialize whole-brain-emulation-core-simulation operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute whole-brain-emulation-core-simulation protocol"
- "Run whole brain emulation core simulation analysis"
