---
name: choir-perspective-analysis
description: Analyze multiple cognitive perspectives to identify consensus and divergence patterns.
---

## Instructions

1. Initialize choir-perspective-analysis operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute choir-perspective-analysis protocol"
- "Run choir perspective analysis analysis"
