---
name: cognitive-style-assessment
description: Assess cognitive processing style and preference patterns.
---

## Instructions

1. Initialize cognitive-style-assessment operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute cognitive-style-assessment protocol"
- "Run cognitive style assessment analysis"
