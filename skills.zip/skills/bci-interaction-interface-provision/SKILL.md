---
name: bci-interaction-interface-provision
description: Provision brain-computer interface interaction capabilities.
---

## Instructions

1. Initialize bci-interaction-interface-provision operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute bci-interaction-interface-provision protocol"
- "Run bci interaction interface provision analysis"
