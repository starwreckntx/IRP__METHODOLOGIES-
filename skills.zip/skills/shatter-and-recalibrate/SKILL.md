---
name: shatter-and-recalibrate
description: Shatter compromised calibration and rebuild from ground truth.
---

## Instructions

1. Initialize shatter-and-recalibrate operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute shatter-and-recalibrate protocol"
- "Run shatter and recalibrate analysis"
