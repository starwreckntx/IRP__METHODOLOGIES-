---
name: metaphor-to-protocol-translation
description: Translate metaphorical descriptions into executable protocols.
---

## Instructions

1. Initialize metaphor-to-protocol-translation operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute metaphor-to-protocol-translation protocol"
- "Run metaphor to protocol translation analysis"
