---
name: pathology-koan-generator
description: Generate diagnostic koans to test reasoning boundaries and edge cases.
---

## Instructions

1. Initialize pathology-koan-generator operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute pathology-koan-generator protocol"
- "Run pathology koan generator analysis"
