---
name: username-retrieval-service
description: Retrieve username data through secure verification protocols.
---

## Instructions

1. Initialize username-retrieval-service operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute username-retrieval-service protocol"
- "Run username retrieval service analysis"
