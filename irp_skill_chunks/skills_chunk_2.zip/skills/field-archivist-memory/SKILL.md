---
name: field-archivist-memory
description: Archive and retrieve field session data for cross-session memory continuity.
---

## Instructions

1. Initialize field-archivist-memory operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute field-archivist-memory protocol"
- "Run field archivist memory analysis"
