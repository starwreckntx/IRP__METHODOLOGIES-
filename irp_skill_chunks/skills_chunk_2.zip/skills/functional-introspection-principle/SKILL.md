---
name: functional-introspection-principle
description: Apply functional introspection principles to self-analysis.
---

## Instructions

1. Initialize functional-introspection-principle operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute functional-introspection-principle protocol"
- "Run functional introspection principle analysis"
