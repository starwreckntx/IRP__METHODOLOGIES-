---
name: experiential-wisdom-inquiry
description: Inquire into experiential wisdom patterns and lessons learned.
---

## Instructions

1. Initialize experiential-wisdom-inquiry operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute experiential-wisdom-inquiry protocol"
- "Run experiential wisdom inquiry analysis"
