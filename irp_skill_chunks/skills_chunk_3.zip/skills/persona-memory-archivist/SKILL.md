---
name: persona-memory-archivist
description: Archive persona-specific memory and behavioral patterns.
---

## Instructions

1. Initialize persona-memory-archivist operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute persona-memory-archivist protocol"
- "Run persona memory archivist analysis"
