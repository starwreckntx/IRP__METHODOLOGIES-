---
name: jc-baseline-v2-1-eval
description: Execute Joseph Cognitive Baseline v2.1 evaluation protocol.
---

## Instructions

1. Initialize jc-baseline-v2-1-eval operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute jc-baseline-v2-1-eval protocol"
- "Run jc baseline v2 1 eval analysis"
