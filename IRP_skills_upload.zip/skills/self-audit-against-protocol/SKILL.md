---
name: self-audit-against-protocol
description: Audit own behavior against protocol specifications.
---

## Instructions

1. Initialize self-audit-against-protocol operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute self-audit-against-protocol protocol"
- "Run self audit against protocol analysis"
