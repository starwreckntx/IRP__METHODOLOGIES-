---
name: predictive-persona-performance
description: Predict persona performance in specific task contexts.
---

## Instructions

1. Initialize predictive-persona-performance operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute predictive-persona-performance protocol"
- "Run predictive persona performance analysis"
