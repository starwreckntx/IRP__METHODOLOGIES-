---
name: mental-saccade-execution
description: Execute rapid attention shifts between cognitive focus points.
---

## Instructions

1. Initialize mental-saccade-execution operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute mental-saccade-execution protocol"
- "Run mental saccade execution analysis"
