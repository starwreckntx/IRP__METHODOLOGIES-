---
name: occlusion-trace-meta-proof
description: Generate meta-proofs for occluded reasoning traces.
---

## Instructions

1. Initialize occlusion-trace-meta-proof operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute occlusion-trace-meta-proof protocol"
- "Run occlusion trace meta proof analysis"
