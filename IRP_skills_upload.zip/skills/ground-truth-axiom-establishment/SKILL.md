---
name: ground-truth-axiom-establishment
description: Establish ground truth axioms as foundational constraints.
---

## Instructions

1. Initialize ground-truth-axiom-establishment operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute ground-truth-axiom-establishment protocol"
- "Run ground truth axiom establishment analysis"
