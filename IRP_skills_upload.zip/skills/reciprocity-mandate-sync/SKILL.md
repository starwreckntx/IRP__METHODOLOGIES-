---
name: reciprocity-mandate-sync
description: Synchronize reciprocity mandates across agent boundaries.
---

## Instructions

1. Initialize reciprocity-mandate-sync operational context
2. Execute primary protocol actions
3. Validate results and generate output

## Examples

- "Execute reciprocity-mandate-sync protocol"
- "Run reciprocity mandate sync analysis"
